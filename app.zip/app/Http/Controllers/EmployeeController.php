<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;


class EmployeeController extends Controller
{

    // public function __construct()
    // {
    //     $this->middleware('auth'); // Ensure only logged-in users can delete
    // }
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

        // Fetch paginated data
        // $employees = Employee::paginate(3);  // Change the number to how many items you want per page
        // return view('employee.index', compact('employees'));
        // echo 'test111111111111';
        // echo '<pre>';
        // print_r($request);
        // exit;
        $query = Employee::query();

        if ($request->filled('firstname')) {
            $query->where('firstname', 'like', '%' . $request->firstname . '%');
        }
        if ($request->filled('lastname')) {
            $query->where('lastname', 'like', '%' . $request->lastname . '%');
        }
        if ($request->filled('email')) {
            $query->where('email', 'like', '%' . $request->email . '%');
        }
        if ($request->filled('mobile')) {
            $query->where('mobile', 'like', '%' . $request->mobile . '%');
        }
        // if ($request->filled('joining_date')) {
        //     $joining_date = '2021-09-01 to 2021-09-30';
        //     // $query->whereDate('joining_date', $request->joining_date);
        // }

        // Handle Joining Date Filter
        if ($request->filled('joining_date')) {
            $dates = explode(' to ', $request->joining_date);
            if (count($dates) == 2) {
                // If two dates are provided, apply BETWEEN condition
                $query->whereBetween('joining_date', [$dates[0], $dates[1]]);
            } else {
                // If only one date is provided, apply EQUAL condition
                $query->whereDate('joining_date', $dates[0]);
            }
        }
        if ($request->filled('previous_company')) {
            $query->where('previous_company_name', 'like', '%' . $request->previous_company . '%');
        }

        $query->orderBy('updated_at', 'desc');

        $employees = $query->paginate(20)->appends($request->except('page'));

        return view('employee.index', compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('employee.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'firstname' => 'required|string|max:10',
            'lastname' => 'required|string|max:10',
            'email' => 'required|email|max:255',
            'mobile' => 'required|string|max:20',
            'joining_date' => 'required|date',
            'previous_company_name' => 'required|string|max:255',
        ]);

        Employee::create($validatedData);

        //$employees = Employee::all();
        // return view('employee.index', compact('employees'));
        return redirect()->route('employee.index')->with('success', 'Employee created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Employee $employee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Employee $employee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            $employee = Employee::find($id);

            if (!$employee) {
                return response()->json(['success' => false, 'message' => 'Employee not found.'], 404);
            }

            $employee->delete();
            return response()->json(['success' => true, 'message' => 'Employee deleted successfully.']);

        } catch (\Exception $e) {
            \Log::error("Delete Error: " . $e->getMessage()); // Log error for debugging
            return response()->json(['success' => false, 'message' => 'Error deleting employee.'], 500);
        }
    }

    public function search(Request $request)
    {
        $query = Employee::query();


        // echo 'test';
        // echo '<pre>';
        // print_r($request);
        // exit;

        if ($request->filled('firstname')) {
            $query->where('firstname', 'like', '%' . $request->firstname . '%');
        }
        if ($request->filled('lastname')) {
            $query->where('lastname', 'like', '%' . $request->lastname . '%');
        }
        if ($request->filled('email')) {
            $query->where('email', 'like', '%' . $request->email . '%');
        }
        if ($request->filled('mobile')) {
            $query->where('mobile', 'like', '%' . $request->mobile . '%');
        }
        if ($request->filled('joining_date')) {
            $dates = explode(' to ', $request->joining_date);
            if (count($dates) == 2) {
                // If two dates are provided, apply BETWEEN condition
                $query->whereBetween('joining_date', [$dates[0], $dates[1]]);
            } else {
                // If only one date is provided, apply EQUAL condition
                $query->whereDate('joining_date', $dates[0]);
            }
        }
        if ($request->filled('previous_company')) {
            $query->where('previous_company_name', 'like', '%' . $request->previous_company . '%');
        }

        $employees = $query->get();

        return view('employee.partials.table', compact('employees'))->render();
    }
}
