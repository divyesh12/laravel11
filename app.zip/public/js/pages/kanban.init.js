(function($) {
    "use strict";
    var KanbanBoard = function() {
        this.$body = $("body");
    };

    // Initialize sortable for task lists
    $("#upcoming, #inprogress, #completed").sortable({
        connectWith: ".taskList",
        placeholder: "task-placeholder",
        forcePlaceholderSize: true,
        update: function(event, ui) {
            // Update the order arrays
            var upcoming = $("#upcoming").sortable("toArray");
            var inProgress = $("#inprogress").sortable("toArray");
            var completed = $("#completed").sortable("toArray");
            console.log(upcoming);

           // console.log(upcoming, inProgress, completed); // You can handle updates here
        }
    }).disableSelection();

    KanbanBoard.prototype.init = function() {
        // Additional initialization code here if needed
    };

    // Create the KanbanBoard object
    $.KanbanBoard = new KanbanBoard();
    $.KanbanBoard.Constructor = KanbanBoard;

})(window.jQuery);

(function($) {
    "use strict";
    // Initialize the KanbanBoard
    $.KanbanBoard.init();
})(window.jQuery);
