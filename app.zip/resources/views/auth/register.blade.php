<x-guest-layout>
    @if ($errors->any())
    <div class="demo-spacing-0">
        <div class="alert alert-danger mt-1 alert-validation-msg" role="alert" style="display: block;">
            <div class="alert-body d-flex align-items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-info me-50">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
                @foreach ($errors->all() as $error)
                <span>{{ $error }}</span>
                @endforeach
            </div>
        </div>
    </div>
    @endif
    <form method="POST" class="auth-login-form mt-2 parsley-examples" action="{{ route('register') }}">
        @csrf
        <div class="form-group">
            <label for="fullname">Full Name</label>
            <input class="form-control" id="name" type="text" name="name" required="required" autofocus="autofocus"
                autocomplete="name">
        </div>
        <div class="form-group">
            <label for="emailaddress">Email address</label>
            <input class="form-control" id="email" type="email" name="email" required="required"
                autocomplete="username">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input class="form-control" id="password" type="password" name="password" required="required"
                autocomplete="new-password">
        </div>
        <div class="form-group">
            <label for="password">Confirm Password</label>
            <input class="form-control" id="password_confirmation" type="password" name="password_confirmation"
                required="required" autocomplete="new-password">
        </div>
        <div class="form-group mb-0 text-center">
            <button class="btn btn-success btn-block" type="submit"> Sign Up </button>
        </div>
    </form>
</x-guest-layout>