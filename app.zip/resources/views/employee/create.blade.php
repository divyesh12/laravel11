<!-- ============================================================== -->
<!-- Start Page Content here -->
<!-- ============================================================== -->
<x-app-layout>
    @section('style')
        <link href="{{ asset('libs/flatpickr/flatpickr.min.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('css/icons.min.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('css/app.min.css') }}" rel="stylesheet" type="text/css">
    @endsection
    <div class="wrapper">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Employee</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">edit</a></li>
                                <li class="breadcrumb-item active">form</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Create Employee</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif

                            <form action="{{ route('employee.store') }}" method="POST" class="needs-validation"
                                novalidate>
                                @csrf

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="firstname">First Name</label>
                                            <input type="text" class="form-control @error('firstname') is-invalid @enderror" 
                                                id="firstname" name="firstname" value="{{ old('firstname') }}" >
                                            @error('firstname')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="lastname">Last name</label>
                                            <input type="text" class="form-control @error('lastname') is-invalid @enderror" 
                                                id="lastname" name="lastname" value="{{ old('lastname') }}" >
                                            @error('lastname')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="email">Email</label>
                                            <input type="text" class="form-control @error('email') is-invalid @enderror" 
                                                id="email" name="email" value="{{ old('email') }}" >
                                            @error('email')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="mobile">Mobile No</label>
                                            <input type="text" class="form-control @error('mobile') is-invalid @enderror" 
                                                id="mobile" name="mobile" value="{{ old('mobile') }}" >
                                            @error('mobile')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="joining_date">Joining Date</label>
                                            <input type="date" class="form-control @error('joining_date') is-invalid @enderror" 
                                                id="joining_date" name="joining_date" value="{{ old('joining_date') }}" >
                                            @error('joining_date')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="previous_company_name">Previous Company Name</label>
                                            <input type="text" class="form-control @error('previous_company_name') is-invalid @enderror" id="previous_company_name" name="previous_company_name" value="{{ old('previous_company_name') }}" >
                                            @error('previous_company_name')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-primary" type="submit">Submit form</button>
                            </form>

                        </div> <!-- end card-body-->
                    </div> <!-- end card-->
                </div> <!-- end col-->
            </div>
        </div>
    </div>
    <!-- end wrapper -->

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->
    @section('scripts')
        <!-- Vendor js -->
        <script src="{{asset('js/vendor.min.js')}}"></script>

        <!-- Plugins js-->
        <!-- <script src="{{asset('libs/flatpickr/flatpickr.min.js')}}"></script> -->
        <script src="{{asset('js/pages/form-pickers.init.js')}}"></script>
        <!-- App js-->
        <script src="{{asset('js/app.min.js')}}"></script>
        <!-- Additional scripts can be included here -->
    @endsection
</x-app-layout>