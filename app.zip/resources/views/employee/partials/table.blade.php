@foreach ($employees as $employee)
<tr>
    <td>{{ $employee->firstname }}</td>
    <td>{{ $employee->lastname }}</td>
    <td>{{ $employee->email }}</td>
    <td>{{ $employee->mobile }}</td>
    <td>{{ \Carbon\Carbon::parse($employee->joining_date)->format(config('app.date_format')) }}</td>
    <td>{{ $employee->previous_company_name }}</td>
    <td>
        <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
        <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
    </td>
</tr>
@endforeach
