<!-- ============================================================== -->
<!-- Start Page Content here -->
<!-- ============================================================== -->
<x-app-layout>
    @section('style')
        <link href="{{ asset('libs/flatpickr/flatpickr.min.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('css/icons.min.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('css/app.min.css') }}" rel="stylesheet" type="text/css">
    @endsection
    <div class="wrapper">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Employee</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">edit</a></li>
                                <li class="breadcrumb-item active">form</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Create Employee</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif

                            <form action="{{ route('employee.store') }}"method="POST" class="needs-validation"
                                novalidate>
                                @csrf
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="firstname">First name</label>
                                            <input type="text" class="form-control" id="firstname" name="firstname"
                                                placeholder="First name" required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide a first name.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="lastname">Last name</label>
                                            <input type="text" class="form-control" id="lastname" name="lastname"
                                                placeholder="Last name" required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide a last name.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="email">Email</label>
                                            <input type="email" class="form-control" id="email" name="email"
                                                placeholder="Email" required>
                                            <div class="invalid-feedback">
                                                Please provide a valid email.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="mobile">Mobile No</label>
                                            <input type="text" class="form-control" id="mobile" name="mobile"
                                                placeholder="Mobile No" required>
                                            <div class="invalid-feedback">
                                                Please provide a valid mobile number.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="joining_date">Joining Date</label>
                                            <input type="date" class="form-control" name="joining_date" placeholder="Joining Date" required>
                                            <div class="invalid-feedback">
                                                Please provide a valid joining date.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="previous_company_name">Previous Company Name</label>
                                            <input type="text" class="form-control" id="previous_company_name"
                                                name="previous_company_name" placeholder="Previous Company Name"
                                                required>
                                            <div class="invalid-feedback">
                                                Please provide a valid previous company name.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-primary" type="submit">Submit form</button>
                            </form>

                        </div> <!-- end card-body-->
                    </div> <!-- end card-->
                </div> <!-- end col-->
            </div>
        </div>
    </div>
    <!-- end wrapper -->

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->
    @section('scripts')
    <!-- Vendor js -->
    <script src="{{asset('js/vendor.min.js')}}"></script>
    <script src="{{asset('libs/jquery-ui/jquery-ui.min.js')}}"></script>
    <script src="{{asset('js/pages/kanban.init.js')}}"></script>
    <script src="{{asset('js/app.min.js')}}"></script>
    @endsection
</x-app-layout>