<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

    <head>
            <meta charset="utf-8">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <title>{{ config('app.name', 'Laravel') }}</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
            <meta content="Coderthemes" name="author">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <!-- App favicon -->
            <link rel="shortcut icon" href="{{asset('images/favicon.ico')}}">

            <!-- Plugins css -->
            <link href="{{asset('libs/flatpickr/flatpickr.min.css')}}" rel="stylesheet" type="text/css">

            <!-- App css -->
            <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
            <link href="{{asset('css/icons.min.css')}}" rel="stylesheet" type="text/css">
            <link href="{{asset('css/app.min.css')}}" rel="stylesheet" type="text/css">
            <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
            
            @yield('styles')
            <style>
                .navigation-menu>li.last-elements .submenu>li.has-submenu .submenu {
                    left: 100%;
                    margin-left: 0;
                    margin-right: 10px;
                }
            </style>
    </head>
    <body>
        @include('layouts.navigation')

        <main>
            {{ $slot }}
        </main>

        <!-- BEGIN: Vendor JS-->
        <!-- <script src="{{asset('js/vendor.min.js')}}"></script> -->
        <!-- BEGIN Vendor JS-->

        <!-- <script src="{{asset('js/app.min.js')}}"></script> -->
        <!-- END: Theme JS-->

        @yield('scripts')
    </body>
</html>
