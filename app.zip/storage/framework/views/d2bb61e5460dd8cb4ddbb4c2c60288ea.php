<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
            <meta charset="utf-8">
            <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
            <title><?php echo e(config('app.name', 'Laravel')); ?></title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
            <meta content="Coderthemes" name="author">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <!-- App favicon -->
            <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">

            <!-- Plugins css -->
            <link href="<?php echo e(asset('libs/flatpickr/flatpickr.min.css')); ?>" rel="stylesheet" type="text/css">

            <!-- App css -->
            <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
            <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
            <link href="<?php echo e(asset('css/app.min.css')); ?>" rel="stylesheet" type="text/css">
            <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
            
            <?php echo $__env->yieldContent('styles'); ?>
            <style>
                .navigation-menu>li.last-elements .submenu>li.has-submenu .submenu {
                    left: 100%;
                    margin-left: 0;
                    margin-right: 10px;
                }
            </style>
    </head>
    <body>
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main>
            <?php echo e($slot); ?>

        </main>

        <!-- BEGIN: Vendor JS-->
        <!-- <script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script> -->
        <!-- BEGIN Vendor JS-->

        <!-- <script src="<?php echo e(asset('js/app.min.js')); ?>"></script> -->
        <!-- END: Theme JS-->

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp8.2\htdocs\laravel11\resources\views/layouts/app.blade.php ENDPATH**/ ?>