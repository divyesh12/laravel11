<?php if($paginator->hasPages()): ?>

    <div class="row">
        <div class="col-sm-12 col-md-5">
            <div class="dataTables_info" id="basic-datatable_info" role="status" aria-live="polite">
                <p class="text-sm text-gray-700 leading-5 dark:text-gray-400">
                    <?php echo __('Showing'); ?>

                    <?php if($paginator->firstItem()): ?>
                        <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
                        <?php echo __('to'); ?>

                        <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
                    <?php else: ?>
                        <?php echo e($paginator->count()); ?>

                    <?php endif; ?>
                    <?php echo __('of'); ?>

                    <span class="font-medium"><?php echo e($paginator->total()); ?></span>
                    <?php echo __('results'); ?>

                </p>
            </div>
        </div>
        <div class="col-sm-12 col-md-7">
            <div style="float: inline-end;">
                <ul class="pagination pagination-rounded">
                    
                    <?php if($paginator->onFirstPage()): ?>
                        <li class="paginate_button page-item previous disabled">
                            <span class="page-link"><i class="mdi mdi-chevron-left"></i></span>
                        </li>
                    <?php else: ?>
                        <li class="paginate_button page-item previous">
                            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-link"
                                aria-label="<?php echo app('translator')->get('pagination.previous'); ?>"><i class="mdi mdi-chevron-left"></i></a>
                        </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(is_string($element)): ?>
                            <li class="paginate_button page-item disabled"><span class="page-link"><?php echo e($element); ?></span></li>
                        <?php endif; ?>

                        
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <li class="paginate_button page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                                <?php elseif(
                                        $page == 1 || $page == $paginator->lastPage() || ($page >= $paginator->currentPage() - 1 &&
                                            $page <= $paginator->currentPage() + 1)
                                    ): ?>
                                        <li class="paginate_button page-item"><a href="<?php echo e($url); ?>" class="page-link"><?php echo e($page); ?></a></li>
                                <?php elseif($page == 2 && $paginator->currentPage() > 4): ?>
                                    <li class="paginate_button page-item"><a href="<?php echo e($url); ?>" class="page-link"><?php echo e($page); ?></a></li>
                                <?php elseif(
                                        $page == $paginator->lastPage() - 1 && $paginator->currentPage() < $paginator->lastPage() -
                                        3
                                    ): ?>
                                            <li class="paginate_button page-item"><a href="<?php echo e($url); ?>" class="page-link"><?php echo e($page); ?></a>
                                            </li>
                                <?php elseif($page == $paginator->currentPage() - 2 || $page == $paginator->currentPage() + 2): ?>
                                    <li class="paginate_button page-item disabled"><span class="page-link">...</span></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <?php if($paginator->hasMorePages()): ?>
                                <li class="paginate_button page-item next">
                                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-link"
                                        aria-label="<?php echo app('translator')->get('pagination.next'); ?>"><i class="mdi mdi-chevron-right"></i></a>
                                </li>
                            <?php else: ?>
                                <li class="paginate_button page-item next disabled">
                                    <span class="page-link"><i class="mdi mdi-chevron-right"></i></span>
                                </li>
                            <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

<?php endif; ?><?php /**PATH C:\xampp8.2\htdocs\laravel11\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>