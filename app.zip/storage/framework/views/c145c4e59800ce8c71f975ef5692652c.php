<!-- ============================================================== -->
<!-- Start Page Content here -->
<!-- ============================================================== -->
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('style'); ?>
        <link href="<?php echo e(asset('libs/flatpickr/flatpickr.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/app.min.css')); ?>" rel="stylesheet" type="text/css">
    <?php $__env->stopSection(); ?>
    <div class="wrapper">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                <li class="breadcrumb-item active">Validation</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Form Validation</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Bootstrap Validation - Employee Form</h4>
                            <p class="sub-header">Provide valuable, actionable feedback to your users with HTML5 form
                                validation–available in all our supported browsers.</p>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('employee.store')); ?>" method="POST" class="needs-validation"
                                novalidate>
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="firstname">First name</label>
                                            <input type="text" class="form-control" id="firstname" name="firstname"
                                                placeholder="First name" required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide a first name.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="lastname">Last name</label>
                                            <input type="text" class="form-control" id="lastname" name="lastname"
                                                placeholder="Last name" required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide a last name.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="email">Email</label>
                                            <input type="email" class="form-control" id="email" name="email"
                                                placeholder="Email" required>
                                            <div class="invalid-feedback">
                                                Please provide a valid email.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="mobile">Mobile No</label>
                                            <input type="text" class="form-control" id="mobile" name="mobile"
                                                placeholder="Mobile No" required>
                                            <div class="invalid-feedback">
                                                Please provide a valid mobile number.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="joining_date">Joining Date</label>
                                            <input type="date" class="form-control" name="joining_date" placeholder="Joining Date" required>
                                            <div class="invalid-feedback">
                                                Please provide a valid joining date.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="previous_company_name">Previous Company Name</label>
                                            <input type="text" class="form-control" id="previous_company_name"
                                                name="previous_company_name" placeholder="Previous Company Name"
                                                required>
                                            <div class="invalid-feedback">
                                                Please provide a valid previous company name.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mb-3">
                                    <div class="custom-control custom-checkbox form-check">
                                        <input type="checkbox" class="custom-control-input" id="invalidCheck" required>
                                        <label class="custom-control-label" for="invalidCheck">Agree to terms and
                                            conditions</label>
                                        <div class="invalid-feedback">
                                            You must agree before submitting.
                                        </div>
                                    </div>
                                </div>

                                <button class="btn btn-primary" type="submit">Submit form</button>
                            </form>

                        </div> <!-- end card-body-->
                    </div> <!-- end card-->
                </div> <!-- end col-->
            </div>
        </div>
    </div>
    <!-- end wrapper -->

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->
    <?php $__env->startSection('scripts'); ?>
    <!-- Vendor js -->
    <script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script>

    <!-- Plugins js-->
    <!-- <script src="<?php echo e(asset('libs/flatpickr/flatpickr.min.js')); ?>"></script> -->
    <script src="<?php echo e(asset('js/pages/form-pickers.init.js')); ?>"></script>
    
    <!-- <script src="<?php echo e(asset('libs/bootstrap-colorpicker/bootstrap-colorpicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/clockpicker/bootstrap-clockpicker.min.js')); ?>"></script> -->

    <!-- Init js-->
   
    <!-- Validation init js-->
    <!-- <script src="<?php echo e(asset('js/pages/form-validation.init.js')); ?>"></script> -->

    <!-- App js-->
    <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
    <!-- Additional scripts can be included here -->
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp8.2\htdocs\laravel11\resources\views/contact/create.blade.php ENDPATH**/ ?>