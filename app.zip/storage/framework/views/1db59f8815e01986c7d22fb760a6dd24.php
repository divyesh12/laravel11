<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->
    <style>
    .jsgrid .jsgrid-button {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        background-image: url(../images/jsgrid.png);
        background-color: #f7f7f7;
        outline: 0 !important;
    }
    </style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <div class="wrapper">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                <li class="breadcrumb-item active">Basic</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Employee</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card-box">
                        <div class="mb-2" style="float:inline-end">
                            <div class="row">
                                <div class="col-4 text-sm-right form-inline">
                                    <div class="form-group mr-2">
                                        <a href="<?php echo e(url('employee/create')); ?>">
                                            <button id="demo-btn-addrow" class="btn btn-primary"><i class="mdi mdi-plus-circle mr-2"></i> Add New Employee</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Joining Date</th>
                                        <th>Previous Company Name</th>
                                        <th>#</th>
                                    </tr>
                                    <tr>
                                        <th><input type="text" class="form-control" id="firstname_search" placeholder="First Name" value="<?php echo e(request('firstname')); ?>"></th>
                                        <th><input type="text" class="form-control" id="lastname_search" placeholder="Last Name" value="<?php echo e(request('lastname')); ?>"></th>
                                        <th><input type="text" class="form-control" id="email_search" placeholder="Email" value="<?php echo e(request('email')); ?>"></th>
                                        <th><input type="text" class="form-control" id="mobile_search" placeholder="Mobile" value="<?php echo e(request('mobile')); ?>"></th>
                                        <th><input type="date" class="form-control" id="range-datepicker" placeholder="Joining Date" value="<?php echo e(request('joining_date')); ?>"></th>
                                        <th><input type="text" class="form-control" id="previous_company_search" placeholder="Previous Company Name" value="<?php echo e(request('previous_company')); ?>"></th>
                                        <th>
                                            <button id="search-button" class="btn btn-primary"><i class="fa fa-search mr-2"></i>Search</button>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody id="employees-table-body">
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($employee->firstname); ?></td>
                                            <td><?php echo e($employee->lastname); ?></td>
                                            <td><?php echo e($employee->email); ?></td>
                                            <td><?php echo e($employee->mobile); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($employee->joining_date)->format(config('app.date_format'))); ?></td>
                                            <td><?php echo e($employee->previous_company_name); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                                                <button type="button" class="btn btn-danger delete-employee" data-id="<?php echo e($employee->id); ?>">
                                                    <i class="far fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <br><br>
                        <?php echo e($employees->appends(request()->input())->links('vendor.pagination.custom')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->
     <?php $__env->startSection('scripts'); ?>

             <!-- Vendor js -->
             <script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script>

        <!-- Plugins js-->
        <script src="<?php echo e(asset('libs/flatpickr/flatpickr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/clockpicker/bootstrap-clockpicker.min.js')); ?>"></script>

        
        <script src="<?php echo e(asset('js/pages/form-pickers.init.js')); ?>"></script>
        <!-- App js-->
        <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
        <!-- Additional scripts can be included here -->

                <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
                <script type="text/javascript">
                $(document).ready(function() {
                    var isSearchActive = false;

                    $('#search-button').on('click', function() {
                        if (isSearchActive) {
                            // Clear the search input fields
                            $('#firstname_search').val('');
                            $('#lastname_search').val('');
                            $('#email_search').val('');
                            $('#mobile_search').val('');
                            $('#range-datepicker').val('');
                            $('#previous_company_search').val('');

                            // Reset the button
                            $(this).removeClass('btn-danger').addClass('btn-primary').text('Search');
                            isSearchActive = false;
                            location.reload();
                        } else {
                            var firstname = $('#firstname_search').val();
                            var lastname = $('#lastname_search').val();
                            var email = $('#email_search').val();
                            var mobile = $('#mobile_search').val();
                            var joining_date = $('#range-datepicker').val();
                            var previous_company = $('#previous_company_search').val();

                            $.ajax({
                                url: '<?php echo e(route("employee.index")); ?>',
                                method: 'GET',
                                data: {
                                    firstname: firstname,
                                    lastname: lastname,
                                    email: email,
                                    mobile: mobile,
                                    joining_date: joining_date,
                                    previous_company: previous_company
                                },
                                success: function(response) {
                                    $('#employees-table-body').html($(response).find('#employees-table-body').html());
                                    $('.pagination').html($(response).find('.pagination').html());

                                    // Change the button to clear state
                                    $('#search-button').removeClass('btn-primary').addClass('btn-danger').text('Clear');
                                    isSearchActive = true;
                                }
                            });
                        }
                    });

                    // Handle pagination click
                    $(document).on('click', '.pagination a', function(event) {
                        event.preventDefault();

                        var page = $(this).attr('href').split('page=')[1];
                        var firstname = $('#firstname_search').val();
                        var lastname = $('#lastname_search').val();
                        var email = $('#email_search').val();
                        var mobile = $('#mobile_search').val();
                        var joining_date = $('#range-datepicker').val();
                        var previous_company = $('#previous_company_search').val();

                        $.ajax({
                            url: '<?php echo e(route("employee.index")); ?>',
                            method: 'GET',
                            data: {
                                page: page,
                                firstname: firstname,
                                lastname: lastname,
                                email: email,
                                mobile: mobile,
                                joining_date: joining_date,
                                previous_company: previous_company
                            },
                            success: function(response) {
                                $('#employees-table-body').html($(response).find('#employees-table-body').html());
                                $('.pagination').html($(response).find('.pagination').html());
                            }
                        });
                    });
                

                    $(".delete-employee").click(function() {
                        var employeeId = $(this).data("id");

                        if (!confirm("Are you sure you want to delete this employee?")) {
                            return;
                        }

                        // $.ajax({
                        //     url: "<?php echo e(route('employee.destroy', '')); ?>/" + employeeId,
                        //     type: "DELETE",
                        //     data: {
                        //         _token: "<?php echo e(csrf_token()); ?>"
                        //     },
                        //     success: function(response) {
                        //         if (response.success) {
                        //             alert(response.message);
                        //             location.reload(); // Refresh the page after deletion
                        //         } else {
                        //             alert("Failed to delete employee.");
                        //         }
                        //     },
                        //     error: function(xhr) {
                        //         alert("An error occurred: " + xhr.responseText);
                        //     }
                        // });

                            $.ajax({
                                url: "<?php echo e(url('/employee')); ?>/" + employeeId,  // Construct URL correctly
                                type: "DELETE",
                                data: {
                                    _token: $('meta[name="csrf-token"]').attr("content"),  // Ensure token is sent
                                },
                                success: function(response) {
                                    if (response.success) {
                                        toastr.success(response.message); // Show success message
                                        // location.reload();
                                    } else {
                                        alert("Failed to delete employee: " + response.message);
                                    }
                                },
                                error: function(xhr, status, error) {
                                    console.error(xhr.responseText);
                                    alert("Error: " + xhr.responseText);
                                }
                            });
                        });
                    });


                </script>
     <?php $__env->stopSection(); ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp8.2\htdocs\laravel11\resources\views/employee/index.blade.php ENDPATH**/ ?>