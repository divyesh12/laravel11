<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($employee->firstname); ?></td>
    <td><?php echo e($employee->lastname); ?></td>
    <td><?php echo e($employee->email); ?></td>
    <td><?php echo e($employee->mobile); ?></td>
    <td><?php echo e(\Carbon\Carbon::parse($employee->joining_date)->format(config('app.date_format'))); ?></td>
    <td><?php echo e($employee->previous_company_name); ?></td>
    <td>
        <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
        <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp8.2\htdocs\laravel11\resources\views/employee/partials/table.blade.php ENDPATH**/ ?>